import React from "react";
import "./style.css";

export const MainLandngPage = () => {
  return (
    <div className="main-landng-page">
      <div className="main">
        <div className="frame">
          <div className="overlap-group">
            <img className="fsegrdtfg" alt="Fsegrdtfg" src="/img/fsegrdtfg-1.png" />
            <img className="rectangle" alt="Rectangle" src="/img/rectangle-8.svg" />
            <div className="div" />
            <p className="text-wrapper">Are you a student committed to sustainability?</p>
            <p className="p">
              Pre-register today to unlock exclusive discounts on your upcoming ELECTO rides. Join us in our
              eco-conscious journey and save while you travel green!
            </p>
            <div className="rectangle-2" />
            <div className="rectangle-3" />
            <div className="text-wrapper-2">Enter your email</div>
            <div className="text-wrapper-3">Register now</div>
          </div>
          <p className="text-wrapper-4">
            We are at the forefront of transforming urban transportation into a sustainable force. Our mission is to
            offer accessible, eco-conscious transportation solutions that provide individual convenience while making a
            substantial positive impact on our planet.
          </p>
          <img className="safdgfhg" alt="Safdgfhg" src="/img/safdgfhg-1.png" />
          <div className="text-wrapper-5">Home</div>
          <div className="text-wrapper-6">About us</div>
          <div className="text-wrapper-7">Service</div>
          <div className="text-wrapper-8">Impact</div>
          <div className="text-wrapper-9">Contact us</div>
          <div className="text-wrapper-10">Welcome to ELECTO</div>
          <div className="text-wrapper-11">Why Electo</div>
          <div className="text-wrapper-12">Your Eco-Friendly Ride Solution</div>
          <div className="overlap">
            <div className="text-wrapper-13">Enter your email</div>
          </div>
          <div className="div-wrapper">
            <div className="text-wrapper-14">Join now</div>
          </div>
          <div className="text-wrapper-15">Electric</div>
          <div className="text-wrapper-16">Green</div>
          <div className="text-wrapper-17">Affordable</div>
          <img className="sfdghftyjg" alt="Sfdghftyjg" src="/img/sfdghftyjg-1.png" />
          <img className="line" alt="Line" src="/img/line-2.svg" />
          <img className="img" alt="Line" src="/img/line-2.svg" />
          <div className="text-wrapper-18">?</div>
          <div className="text-wrapper-19">Eco-Friendly Mobility</div>
          <div className="overlap-2">
            <div className="text-wrapper-20">Affordable</div>
            <p className="text-wrapper-21">
              With ElectoRide, you can enjoy affordable and cheaper fares compared to other ride services, making it
              easier on your wallet
            </p>
          </div>
          <div className="text-wrapper-22">Sustainable transportation options</div>
          <p className="text-wrapper-23">
            ELECTO boasts an array of electric and green transportation options, from bikes to autos and cars allowing
            you to contribute to a cleaner environment while enjoying your ride.
          </p>
          <p className="text-wrapper-24">
            By choosing ElectoRide, you are making a sustainable choice for your transportation needs, reducing your
            carbon footprint and promoting a greener future.
          </p>
          <img className="wrydthfghvjb" alt="Wrydthfghvjb" src="/img/wrydthfghvjb.png" />
          <img className="line-2" alt="Line" src="/img/line-3.svg" />
          <div className="text-wrapper-25">All rights reserved</div>
          <img className="ghts" alt="Ghts" src="/img/ghts-1.png" />
          <img className="vgers" alt="Vgers" src="/img/vgers-1.png" />
        </div>
      </div>
    </div>
  );
};
